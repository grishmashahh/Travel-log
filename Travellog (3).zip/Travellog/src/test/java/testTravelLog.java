package com.v;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
public class testTravelLog {

    @SpringBootTest
    class DemoApplicationTests {

        @Test
        void contextLoads() {
        }

    }

}
