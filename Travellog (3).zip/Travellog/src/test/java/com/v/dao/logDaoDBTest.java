package com.v.dao;

import org.junit.Ignore;
import org.junit.jupiter.api.Test;

class logDaoDBTest {

    @Ignore

    public void testFindUnattachedLocations() {
        Location location = new Location();
        location.setLatitude(10.00564325);
        location.setLongitude(-10.00564325);

        repo.save(location);

        List<Location> locations = repo.findUnattachedLocations();
        assertTrue(locations.size() >= 1);
    }

    @Test
    void addTL() {
    }

    @Test
    void updateTL() {
    }

    @Test
    void delete() {

        Result result = service.deleteById(1);

        assertTrue(result.isSuccess());
    }

    @Test
    void ALLlog() {
    }

    @Test
    void search() {
    }

    @Test
    void deleteTL() {
    }
}