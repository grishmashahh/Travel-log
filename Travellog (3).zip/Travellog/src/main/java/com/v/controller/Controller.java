package com.v.controller;

import com.v.model.User;
import com.v.service.travelLogServiceLayer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;

    @RestController
    @RequestMapping("/api")
    public class Controller {

    @Autowired
    travelLogServiceLayer service;

        @GetMapping("/register")
        public String showForm(Model model) {
            User user = new User();
            model.addAttribute("user", user);

            List<String> listProfession = Arrays.asList("Developer", "Tester", "Architect");
            model.addAttribute("listProfession", listProfession);

            return "register_form";
        }

        @PostMapping("/register")
        public String submitForm(@ModelAttribute("user") User user) {
            System.out.println(user);
            return "register_success";
        }

        @PostMapping("/AddTL")
        public void AddTL(@PathVariable("AddTL") int id){
            service.AddTL();
        }

        @PostMapping("/EditTL")
        public void EditTL(@PathVariable("EditTL") int id){
            service.EditTL();
        }

        @PostMapping("/Alllog")
        public void AllLog(@PathVariable("ALLLog") int id){
            service.ALLlog();
        };




    }

