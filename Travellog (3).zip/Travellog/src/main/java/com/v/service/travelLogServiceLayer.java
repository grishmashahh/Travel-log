package com.v.service;

import com.v.dao.logDao;
import com.v.model.travelLog;
import org.springframework.beans.factory.annotation.Autowired;

public class travelLogServiceLayer {

    @Autowired
    logDao dao;

    //Scanner scanner = new Scanner(System.in);
    public void AddTL(){
    dao.AddTL(new travelLog());
        return ;
    }

    public void EditTL(){
        dao.UpdateTL(new travelLog());

    }

    public void ALLlog() {
        dao.ALLlog(new travelLog());
    }
}
