package com.v.model;

public class AddTL {
    int id;
    String Firstname;
    String Lastname;
    String Country;
    String Experience;
    int costOfTravel;
    String famousSpots;
    String bestTime;
    String Safety;
    String notes;
}
