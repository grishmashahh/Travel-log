package com.v.model;

public class travelLog {

    int id;
    String Firstname;
    String Lastname;
    String Country;
    String Experience;
    int costOfTravel;
    String famousSpots;
    String bestTime;
    String Safety;
    String notes;

    public travelLog(int id, String firstname, String lastname, String country,
                     String experience, int costOfTravel, String famousSpots,
                     String bestTime, String safety, String notes) {
        this.id = id;
        Firstname = firstname;
        Lastname = lastname;
        Country = country;
        Experience = experience;
        this.costOfTravel = costOfTravel;
        this.famousSpots = famousSpots;
        this.bestTime = bestTime;
        Safety = safety;
        this.notes = notes;
    }

    public travelLog() {

    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFirstname() {
        return Firstname;
    }

    public void setFirstname(String firstname) {
        Firstname = firstname;
    }

    public String getLastname() {
        return Lastname;
    }

    public void setLastname(String lastname) {
        Lastname = lastname;
    }

    public String getCountry() {
        return Country;
    }

    public void setCountry(String country) {
        Country = country;
    }

    public String getExperience() {
        return Experience;
    }

    public void setExperience(String experience) {
        Experience = experience;
    }

    public int getCostOfTravel() {
        return costOfTravel;
    }

    public void setCostOfTravel(int costOfTravel) {
        this.costOfTravel = costOfTravel;
    }

    public String getFamousSpots() {
        return famousSpots;
    }

    public void setFamousSpots(String famousSpots) {
        this.famousSpots = famousSpots;
    }

    public String getBestTime() {
        return bestTime;
    }

    public void setBestTime(String bestTime) {
        this.bestTime = bestTime;
    }

    public String getSafety() {
        return Safety;
    }

    public void setSafety(String safety) {
        Safety = safety;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    @Override
    public String toString() {
        return "travelLog{" +
                "id=" + id +
                ", Firstname='" + Firstname + '\'' +
                ", Lastname='" + Lastname + '\'' +
                ", Country='" + Country + '\'' +
                ", Experience='" + Experience + '\'' +
                ", costOfTravel=" + costOfTravel +
                ", famousSpots='" + famousSpots + '\'' +
                ", bestTime='" + bestTime + '\'' +
                ", Safety='" + Safety + '\'' +
                ", notes='" + notes + '\'' +
                '}';
    }
}
