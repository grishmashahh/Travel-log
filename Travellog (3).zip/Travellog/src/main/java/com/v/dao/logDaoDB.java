package com.v.dao;

import com.v.model.travelLog;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
@Repository
public class logDaoDB implements logDao {
     @Autowired
     JdbcTemplate jdbc;

     public logDaoDB(JdbcTemplate jdbcTemplate, JdbcTemplate jdbc){
         this.jdbc = jdbc;
     }

    @Override
    public travelLog AddTL(travelLog Travellog) {
        return Travellog;
    }

    @Override
    public travelLog UpdateTL(travelLog Travellog) {
        return Travellog;
    }

    @Override
    public travelLog Delete(travelLog Travellog) {
        return Travellog;
    }

    @Override
    public String ALLlog(travelLog Travellog) {
         final String SELECT_ALL = "Select * from travellog";
        return SELECT_ALL;
    }

    @Override
    public String Search(String Country) {
        final String SELECT_COUNTRY = "SELECT * FROM country WHERE country = ?";
        return SELECT_COUNTRY;
    }

    @Override
    public String DeleteTL(int id) {
        final String DELETE = "DELETE FROM travellog WHERE id = ?";
        jdbc.update(DELETE, id);
        return DELETE;
    }
}
