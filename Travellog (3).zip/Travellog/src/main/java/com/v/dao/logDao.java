package com.v.dao;

import com.v.model.travelLog;

public interface logDao {

    travelLog AddTL(travelLog Travellog);

    travelLog UpdateTL(travelLog Travellog);

    travelLog Delete(travelLog Travellog);

    String ALLlog(travelLog Travellog);

    String Search(String Country);
    String DeleteTL(int id);
}
