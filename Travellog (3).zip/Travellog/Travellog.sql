DROP DATABASE IF EXISTS Travellog;
CREATE DATABASE Travellog;
USE travellog;
CREATE TABLE Travellog(
id INT PRIMARY KEY AUTO_INCREMENT not null,
firstname varchar(30) not null,
lastname varchar(30) not null,
country varchar(30) not null,
experience varchar(250) not null,
costoftravel decimal(10,2) not null,
famousspots varchar(50) not null,
besttime varchar(40) not null,
safety varchar(40) ,
notes varchar(40) );

CREATE TABLE Country(
country_id INT PRIMARY KEY AUTO_INCREMENT not null,
Experience varchar(30) not null,
country varchar(30) not null,
CONSTRAINT FOREIGN KEY FK_country (country_id)
        REFERENCES travellog (id),
costoftravel decimal(10,2) not null,
famousspots varchar(50) not null,
besttime varchar(40) not null);

CREATE TABLE Experience(
Experience_id INT PRIMARY KEY AUTO_INCREMENT not null,
CONSTRAINT FOREIGN KEY FK_country (experience_id)
        REFERENCES travellog (id),
country varchar(30) not null,
CONSTRAINT FOREIGN KEY FK_country (experience_id)
        REFERENCES country (Country_id),
costoftravel decimal(10,2) not null,
famousspots varchar(50) not null,
besttime varchar(40) not null);


Select * from travellog;
Select * from country;
Select * from experience;

